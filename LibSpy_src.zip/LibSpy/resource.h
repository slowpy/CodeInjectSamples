//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LibSpy.rc
//
#define IDI_MYICON                      2
#define IDD_WININFO                     129
#define IDC_CROSS0                      143
#define IDC_CROSS1                      144
#define IDB_CROSS                       158
#define IDB_BLANK                       159
#define IDC_EDIT1                       1000
#define IDC_EDIT2                       1001
#define IDC_EDIT3                       1002
#define IDC_EDIT4                       1003
#define IDC_EDIT5                       1004
#define IDC_EDIT6                       1005
#define IDC_EDIT7                       1006
#define IDC_EDIT8                       1007
#define IDC_EDIT9                       1008
#define IDC_EDIT10                      1009
#define IDC_EDIT11                      1010
#define IDC_CAPTURE                     1012
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        166
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           111
#endif
#endif
